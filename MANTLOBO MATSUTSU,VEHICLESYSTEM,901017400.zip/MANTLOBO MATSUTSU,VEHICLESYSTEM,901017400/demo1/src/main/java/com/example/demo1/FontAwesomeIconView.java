package com.example.demo1;

import javafx.scene.Node;

public class FontAwesomeIconView extends Node {
    public FontAwesomeIconView(Object p0) {
    }
}
