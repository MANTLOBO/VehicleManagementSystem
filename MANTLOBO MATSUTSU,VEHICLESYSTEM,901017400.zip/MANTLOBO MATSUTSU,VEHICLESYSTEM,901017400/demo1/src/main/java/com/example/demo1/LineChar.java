package com.example.demo1;

import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;

public class LineChar extends LineChart<String, Number> {

    // Main constructor
    public LineChar(CategoryAxis xAxis, NumberAxis yAxis) {
        super(xAxis, yAxis);  // Must call parent constructor with axes
    }


}