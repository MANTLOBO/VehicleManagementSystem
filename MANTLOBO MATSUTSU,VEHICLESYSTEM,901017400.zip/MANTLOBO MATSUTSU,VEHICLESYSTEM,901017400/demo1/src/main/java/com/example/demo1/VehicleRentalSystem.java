package com.example.demo1;

import javafx.animation.*;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.chart.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Glow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Callback;
import javafx.util.Duration;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;


public class VehicleRentalSystem extends Application {
    private final String DB_URL = "jdbc:mysql://localhost:3306/vehiclesystem?useSSL=false&serverTimezone=UTC";
    private final String USER = "root";
    private final String PASS = "123456";

    private String userRole;
    private String loggedInUserId;

    private TableView<Vehicle> vehicleTable = new TableView<>();
    private ObservableList<Vehicle> vehicleList = FXCollections.observableArrayList();
    private TableView<Customer> customerTable = new TableView<>();
    private ObservableList<Customer> customerList = FXCollections.observableArrayList();
    private TableView<Booking> bookingTable = new TableView<>();
    private ObservableList<Booking> bookingList = FXCollections.observableArrayList();
    private TableView<Payment> paymentTable = new TableView<>();
    private ObservableList<Payment> paymentList = FXCollections.observableArrayList();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Vehicle Rental System");
        initializeDatabase();
        login(primaryStage);
    }


    private void initializeDatabase() {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement()) {

            // Create users table with predefined role assignments (Admin for id = 1, Employee for id = 2)
            stmt.execute("CREATE TABLE IF NOT EXISTS users (" +
                    "userId INT PRIMARY KEY AUTO_INCREMENT, " +
                    "username VARCHAR(50) NOT NULL UNIQUE, " +
                    "password VARCHAR(50) NOT NULL, " +
                    "role VARCHAR(20) NOT NULL)");

            // Insert default users if the table is empty
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM users");
            if (rs.next() && rs.getInt(1) == 0) {
                stmt.execute("INSERT INTO users (username, password, role) VALUES ('admin', 'adminss', 'Admin')");
                stmt.execute("INSERT INTO users (username, password, role) VALUES ('employee', 'emppass', 'Employee')");
            }

            // Create vehicles table
            stmt.execute("CREATE TABLE IF NOT EXISTS vehicles (" +
                    "vehicleId VARCHAR(20) PRIMARY KEY, " +
                    "brand VARCHAR(50) NOT NULL, " +
                    "model VARCHAR(50) NOT NULL, " +
                    "category VARCHAR(20) NOT NULL, " +
                    "rentalPrice DECIMAL(10,2) NOT NULL, " +
                    "availability BOOLEAN DEFAULT TRUE)");

            // Create customers table
            stmt.execute("CREATE TABLE IF NOT EXISTS customers (" +
                    "customerId INT PRIMARY KEY, " +
                    "name VARCHAR(100) NOT NULL, " +
                    "contactInfo VARCHAR(100) NOT NULL, " +
                    "drivingLicense VARCHAR(50) NOT NULL)");

            // Create bookings table
            stmt.execute("CREATE TABLE IF NOT EXISTS bookings (" +
                    "bookingId INT PRIMARY KEY AUTO_INCREMENT, " +
                    "customerId INT NOT NULL, " +
                    "vehicleId VARCHAR(20) NOT NULL, " +
                    "startDate DATE NOT NULL, " +
                    "endDate DATE NOT NULL, " +
                    "amount DECIMAL(10,2) NOT NULL, " +
                    "FOREIGN KEY (customerId) REFERENCES customers(customerId), " +
                    "FOREIGN KEY (vehicleId) REFERENCES vehicles(vehicleId))");

            // Create payments table
            stmt.execute("CREATE TABLE IF NOT EXISTS payments (" +
                    "paymentId INT PRIMARY KEY AUTO_INCREMENT, " +
                    "bookingId INT NOT NULL, " +
                    "amount DECIMAL(10,2) NOT NULL, " +
                    "paymentDate DATETIME NOT NULL, " +
                    "paymentMethod VARCHAR(20) NOT NULL, " +
                    "FOREIGN KEY (bookingId) REFERENCES bookings(bookingId))");

        } catch (SQLException e) {
            showAlert("Database Error", "Failed to initialize database: " + e.getMessage());
        }
    }

    private void login(Stage primaryStage) {
        Dialog<ButtonType> loginDialog = new Dialog<>();
        loginDialog.setTitle("User Login");

        // Create a VBox to hold the heading and the login form
        VBox dialogPane = new VBox(10);
        dialogPane.setPadding(new javafx.geometry.Insets(20)); // Padding for better spacing
        loginDialog.getDialogPane().setContent(dialogPane);

        // Add a heading label
        Label headingLabel = new Label("VEHICLE MANAGEMENT SYSTEM:");
        headingLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #333333;"); // Style the heading
        dialogPane.getChildren().add(headingLabel);

        // Create a GridPane for the login form
        GridPane loginGrid = new GridPane();
        loginGrid.setHgap(10);
        loginGrid.setVgap(10);

        TextField usernameField = new TextField();
        PasswordField passwordField = new PasswordField();
        ComboBox<String> roleComboBox = new ComboBox<>();
        roleComboBox.getItems().addAll("Admin", "Employee");
        roleComboBox.setPromptText("Select Role");

        // Add form elements to the grid
        loginGrid.add(new Label("Username:"), 0, 0);
        loginGrid.add(usernameField, 1, 0);
        loginGrid.add(new Label("Password:"), 0, 1);
        loginGrid.add(passwordField, 1, 1);
        loginGrid.add(new Label("Role:"), 0, 2);
        loginGrid.add(roleComboBox, 1, 2);

        // Add the GridPane to the VBox dialog
        dialogPane.getChildren().add(loginGrid);

        // Add buttons for login
        loginDialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        // Styling the buttons
        Button okButton = (Button) loginDialog.getDialogPane().lookupButton(ButtonType.OK);
        Button cancelButton = (Button) loginDialog.getDialogPane().lookupButton(ButtonType.CANCEL);

        // Apply inline styles for buttons
        okButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10px;");
        cancelButton.setStyle("-fx-background-color: #F44336; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10px;");

        // Set a custom style for the dialog pane for a nice background
        dialogPane.setStyle(
                "-fx-background-color: linear-gradient(to bottom, #f6f9fc, #e9eff2); " +
                        "-fx-background-radius: 10px;" +
                        "-fx-effect: dropshadow(three-pass-box, rgba(0, 0, 0, 0.2), 10, 0.5, 0, 0);"
        );

        // Show the dialog and wait for the user response
        Optional<ButtonType> result = loginDialog.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            // Handle successful login
            String username = usernameField.getText();
            String password = passwordField.getText();
            String userRole = roleComboBox.getValue();
            authenticateUser(username, password, primaryStage);
        } else {
            // Close the application if Cancel is pressed
            System.exit(0);
        }
    }
    private void authenticateUser(String username, String password, Stage primaryStage) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?")) {

            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                loggedInUserId = rs.getString("userId");
                userRole = rs.getString("role");  // Set userRole based on logged-in user
                setupUI(primaryStage);
            } else {
                showAlert("Login Failed", "Invalid username or password.");
                login(primaryStage);
            }
        } catch (SQLException e) {
            showAlert("Database Error", "An error occurred while accessing the database: " + e.getMessage());
        }
    }
    private void setupUI(Stage primaryStage) {
        BorderPane mainLayout = new BorderPane();
        VBox sidebar = createSidebar(primaryStage);
        mainLayout.setLeft(sidebar);
        StackPane contentPane = new StackPane();
        contentPane.getChildren().add(createHomeContent(primaryStage));
        mainLayout.setCenter(contentPane);
        Scene scene = new Scene(mainLayout, 900, 650);
        applyCustomStyles(scene);
        primaryStage.setScene(scene);
        primaryStage.show();

        loadVehicles();
        loadCustomers();
        loadBookings();
        loadPayments();
    }

    private void applyCustomStyles(Scene scene) {
        scene.getRoot().setStyle("-fx-font-family: 'Segoe UI'; -fx-background-color: #ffffff;");
        String sidebarStyle = "-fx-background-color: #3498db; -fx-padding: 10px; -fx-spacing: 10px;";
        for (Node node : ((VBox) scene.lookup("#sidebar")).getChildren()) {
            node.setStyle(sidebarStyle);
            if (node instanceof Button) {
                node.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10px; -fx-border-radius: 5;");
                node.setOnMousePressed(e -> node.setStyle("-fx-background-color: #1f618d;"));
                node.setOnMouseReleased(e -> node.setStyle("-fx-background-color: #2980b9;"));
            }
        }


        String tableStyle = "-fx-background-color: #f5f5f5; -fx-font-size: 14px; -fx-padding: 10px; -fx-alignment: center;";
        vehicleTable.setStyle(tableStyle);
        customerTable.setStyle(tableStyle);
        bookingTable.setStyle(tableStyle);
        paymentTable.setStyle(tableStyle);
    }

    private void loadPayments() {
        paymentList.clear();
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM payments");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Payment payment = new Payment(
                        String.valueOf(rs.getInt("paymentId")),
                        String.valueOf(rs.getInt("bookingId")),
                        String.valueOf(rs.getDouble("amount")),
                        rs.getTimestamp("paymentDate").toLocalDateTime().toLocalDate().toString(),
                        rs.getString("paymentMethod"));
                paymentList.add(payment);
            }
            paymentTable.setItems(paymentList);
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to load payments: " + e.getMessage());
        }
    }

    private VBox createSidebar(Stage primaryStage) {
        VBox sidebar = new VBox(10);
        sidebar.setId("sidebar");
        sidebar.setPrefWidth(180);
        sidebar.setStyle("-fx-background-color: #2c3e50; -fx-padding: 15px;");
        sidebar.setAlignment(Pos.TOP_CENTER);

        // Create and style title label
        Label titleLabel = new Label("Vehicle Rental");
        titleLabel.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");
        titleLabel.setPadding(new Insets(0, 0, 20, 0));

        // Create buttons with icons
        Button homeButton = createIconButton("Home", "home");
        homeButton.setOnAction(event -> showHomePage(primaryStage));

        Button vehicleButton = createIconButton("Vehicles", "car");
        vehicleButton.setOnAction(event -> showVehiclePage(primaryStage));

        Button customerButton = createIconButton("Customers", "users");
        customerButton.setOnAction(event -> showCustomerPage(primaryStage));

        Button bookingButton = createIconButton("Bookings", "calendar");
        bookingButton.setOnAction(event -> {
            if ("Customer".equals(userRole)) {
                showCustomerBookingPage(primaryStage);
            } else {
                showBookingPage(primaryStage);
            }
        });

        Button paymentButton = createIconButton("Payments", "credit-card");
        paymentButton.setOnAction(event -> showPaymentPage(primaryStage));

        Button reportButton = createIconButton("Reports", "chart-bar");
        reportButton.setOnAction(event -> showReportPage(primaryStage));

        // Create logout button with different style
        Button logoutButton = createIconButton("Logout", "sign-out");
        logoutButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        logoutButton.setOnAction(event -> handleLogout(primaryStage));

        // Disable unnecessary buttons for employees
        if ("Employee".equals(userRole)) {
            vehicleButton.setDisable(true);
            customerButton.setDisable(true);
            reportButton.setDisable(true);
        }

        // Add all components to the sidebar
        sidebar.getChildren().addAll(titleLabel, homeButton, vehicleButton, customerButton,
                bookingButton, paymentButton, reportButton, new Separator(), logoutButton);

        return sidebar;
    }

    private void showHomePage(Stage primaryStage) {
    }

    private Button createIconButton(String text, String iconName) {
        Button button = new Button(text);

        // Set icon based on iconName (you'll need to implement getIcon method)
        Node icon = getIcon(iconName);

        button.setGraphic(icon);
        button.setContentDisplay(ContentDisplay.LEFT);
        button.setPrefWidth(150);
        button.setAlignment(Pos.CENTER_LEFT);
        button.setStyle("-fx-background-color: #34495e; -fx-text-fill: white; -fx-font-size: 14px;");
        button.setOnMouseEntered(e -> button.setStyle("-fx-background-color: #4a6b8a; -fx-text-fill: white;"));
        button.setOnMouseExited(e -> button.setStyle("-fx-background-color: #34495e; -fx-text-fill: white;"));

        return button;
    }

    private Node getIcon(String iconName) {
        // Using FontAwesome icons (you'll need to include the FontAwesome library)
        // Alternatively, you can use Material Design icons or any other icon library

        // Example using FontAwesome (you'll need the fontawesomefx library)
    /*
    switch (iconName) {
        case "home": return new FontAwesomeIconView(FontAwesomeIcon.HOME);
        case "car": return new FontAwesomeIconView(FontAwesomeIcon.CAR);
        case "users": return new FontAwesomeIconView(FontAwesomeIcon.USERS);
        case "calendar": return new FontAwesomeIconView(FontAwesomeIcon.CALENDAR);
        case "credit-card": return new FontAwesomeIconView(FontAwesomeIcon.CREDIT_CARD);
        case "chart-bar": return new FontAwesomeIconView(FontAwesomeIcon.BAR_CHART);
        case "sign-out": return new FontAwesomeIconView(FontAwesomeIcon.SIGN_OUT);
        default: return new FontAwesomeIconView(FontAwesomeIcon.CIRCLE);
    }
    */

        // Fallback using Unicode symbols if you don't want to use an icon library
        Label iconLabel = new Label();
        iconLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");

        switch (iconName) {
            case "home": iconLabel.setText("⌂"); break;
            case "car": iconLabel.setText("⛟"); break;
            case "users": iconLabel.setText("👥"); break;
            case "calendar": iconLabel.setText("📅"); break;
            case "credit-card": iconLabel.setText("💳"); break;
            case "chart-bar": iconLabel.setText("📊"); break;
            case "sign-out": iconLabel.setText("🚪"); break;
            default: iconLabel.setText("○"); break;
        }

        return iconLabel;
    }
    // Method for creating the Logout button with distinct styling
    private Button createLogoutButton() {
        Button logoutButton = new Button("Logout");

        // Set icon (using FontAwesome or Unicode fallback)
        Node logoutIcon = getIcon("sign-out");
        logoutButton.setGraphic(logoutIcon);
        logoutButton.setContentDisplay(ContentDisplay.LEFT);

        // Base style
        String baseStyle = "-fx-background-color: #F44336; " +  // Red color
                "-fx-text-fill: white; " +
                "-fx-font-weight: bold; " +
                "-fx-font-size: 14px; " +
                "-fx-padding: 10px 15px; " +
                "-fx-border-radius: 5px; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 5, 0, 0, 2);";

        // Hover style (slightly darker red)
        String hoverStyle = "-fx-background-color: #E53935; " +
                "-fx-text-fill: white; " +
                "-fx-font-weight: bold; " +
                "-fx-font-size: 14px; " +
                "-fx-padding: 10px 15px; " +
                "-fx-border-radius: 5px; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 7, 0, 0, 3);";

        // Pressed style (even darker red)
        String pressedStyle = "-fx-background-color: #D32F2F; " +
                "-fx-text-fill: white; " +
                "-fx-font-weight: bold; " +
                "-fx-font-size: 14px; " +
                "-fx-padding: 10px 15px; " +
                "-fx-border-radius: 5px; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 3, 0, 0, 1);";

        // Apply styles
        logoutButton.setStyle(baseStyle);
        logoutButton.setMaxWidth(Double.MAX_VALUE);

        // Event handlers for interactive effects
        logoutButton.setOnMouseEntered(e -> logoutButton.setStyle(hoverStyle));
        logoutButton.setOnMouseExited(e -> logoutButton.setStyle(baseStyle));
        logoutButton.setOnMousePressed(e -> logoutButton.setStyle(pressedStyle));
        logoutButton.setOnMouseReleased(e -> logoutButton.setStyle(hoverStyle));

        return logoutButton;
    }

    private Button createSidebarButton(String text) {
        Button button = new Button(text);
        button.setMaxWidth(Double.MAX_VALUE);
        button.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px; " +
                "-fx-padding: 10px 15px; -fx-border-radius: 5px; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 5, 0, 0, 2);");

        button.setOnMouseEntered(e -> button.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; " +
                "-fx-font-size: 14px; -fx-padding: 10px 15px; -fx-border-radius: 5px; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 7, 0, 0, 3);"));

        button.setOnMouseExited(e -> button.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; " +
                "-fx-font-size: 14px; -fx-padding: 10px 15px; -fx-border-radius: 5px; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 5, 0, 0, 2);"));

        button.setOnMousePressed(e -> button.setStyle("-fx-background-color: #2472a4; -fx-text-fill: white; " +
                "-fx-font-size: 14px; -fx-padding: 10px 15px; -fx-border-radius: 5px; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 3, 0, 0, 1);"));

        return button;
    }
    private Node createHomeContent(Stage primaryStage) {
        // Main container with gradient background
        VBox homeLayout = new VBox(20);
        homeLayout.setPadding(new Insets(20));
        homeLayout.setStyle("-fx-background-color: linear-gradient(to bottom, #1a2a6c, #b21f1f, #fdbb2d);");

        // Create an animated header with shadow effect
        Label welcomeLabel = new Label("Welcome to the Vehicle Rental System!");
        welcomeLabel.setStyle("-fx-font-size: 32px; -fx-font-weight: bold; -fx-text-fill: white; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.8), 10, 0, 0, 0);");

        // Animation for the welcome label
        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(2), welcomeLabel);
        fadeTransition.setFromValue(0.7);
        fadeTransition.setToValue(1.0);
        fadeTransition.setCycleCount(Animation.INDEFINITE);
        fadeTransition.setAutoReverse(true);
        fadeTransition.play();

        // Create a decorative vehicle using JavaFX shapes
        Group vehicleIcon = createVehicleIcon();

        // System status information with auto-refresh
        Label summaryLabel = new Label();
        summaryLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #2c3e50; -fx-font-family: 'Arial';");

        // Auto-refresh timer
        Timeline refreshTimeline = new Timeline(
                new KeyFrame(Duration.seconds(5), event -> updateSummaryLabel(summaryLabel))
        );
        refreshTimeline.setCycleCount(Animation.INDEFINITE);
        refreshTimeline.play();

        // Initial update
        updateSummaryLabel(summaryLabel);

        // Styled container for the summary with hover effect
        VBox summaryBox = new VBox(15, summaryLabel);
        summaryBox.setStyle("-fx-background-color: rgba(255,255,255,0.85); " +
                "-fx-background-radius: 15; " +
                "-fx-padding: 25; " +
                "-fx-border-color: linear-gradient(to right, #1a2a6c, #fdbb2d); " +
                "-fx-border-width: 3; " +
                "-fx-border-radius: 15;");

        // Add hover effect
        summaryBox.setOnMouseEntered(e -> {
            summaryBox.setStyle(summaryBox.getStyle() + "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 15, 0, 0, 0);");
        });
        summaryBox.setOnMouseExited(e -> {
            summaryBox.setStyle(summaryBox.getStyle().replace("-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 15, 0, 0, 0);", ""));
        });

        // Quick action buttons
        HBox quickActions = new HBox(15);
        quickActions.setAlignment(Pos.CENTER);

        Button bookNowBtn = createStyledButton("Book Now", "#1a2a6c");
        Button manageBtn = createStyledButton("Manage Bookings", "#b21f1f");
        Button contactBtn = createStyledButton("Contact Support", "#fdbb2d");

        quickActions.getChildren().addAll(bookNowBtn, manageBtn, contactBtn);

        // Layout organization
        homeLayout.getChildren().addAll(welcomeLabel, vehicleIcon, summaryBox, quickActions);
        homeLayout.setAlignment(Pos.TOP_CENTER);

        return homeLayout;
    }
    private void updateSummaryLabel(Label summaryLabel) {
        summaryLabel.setText(
                String.format(
                        "Current System Status:\n\n" +
                                "🚗 %d vehicles available\n" +
                                "👤 %d registered customers\n" +
                                "📅 %d active bookings\n" +
                                "💳 %d payment records\n\n" +
                                "Need help? Contact us:\n" +
                                "✉ support@vehiclerental.com\n" +
                                "📞 (123) 456-7890\n\n" +
                                "Last updated: %s",
                        vehicleList.size(),
                        customerList.size(),
                        bookingList.size(),
                        paymentList.size(),
                        LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))
                ) // This parenthesis was missing
        );
    }

    private Button createStyledButton(String text, String color) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: " + color + "; " +
                "-fx-text-fill: white; " +
                "-fx-font-weight: bold; " +
                "-fx-font-size: 14px; " +
                "-fx-padding: 10 20; " +
                "-fx-background-radius: 5;");
        button.setOnMouseEntered(e -> button.setStyle(button.getStyle() + "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 5, 0, 0, 0);"));
        button.setOnMouseExited(e -> button.setStyle(button.getStyle().replace("-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 5, 0, 0, 0);", "")));
        return button;
    }

    public Group createVehicleIcn() {
        // Create a more detailed vehicle icon
        Rectangle body = new Rectangle(150, 60);
        body.setFill(Color.DARKBLUE);
        body.setArcWidth(20);
        body.setArcHeight(20);

        Circle wheel1 = new Circle(30, 70, 15, Color.BLACK);
        Circle wheel2 = new Circle(120, 70, 15, Color.BLACK);

        Polygon roof = new Polygon();
        roof.getPoints().addAll(new Double[]{
                50.0, 30.0,
                100.0, 30.0,
                120.0, 60.0,
                30.0, 60.0
        });
        roof.setFill(Color.SKYBLUE);

        Rectangle window1 = new Rectangle(55, 35, 30, 15);
        window1.setFill(Color.LIGHTBLUE);
        Rectangle window2 = new Rectangle(95, 35, 30, 15);
        window2.setFill(Color.LIGHTBLUE);

        // Animation for the vehicle
        TranslateTransition moveTransition = new TranslateTransition(Duration.seconds(8));
        moveTransition.setNode(body);
        moveTransition.setFromX(-200);
        moveTransition.setToX(200);
        moveTransition.setCycleCount(Animation.INDEFINITE);
        moveTransition.setAutoReverse(true);
        moveTransition.play();

        // Apply same animation to all parts
        for (Node part : new Node[]{wheel1, wheel2, roof, window1, window2}) {
            TranslateTransition partTransition = new TranslateTransition(Duration.seconds(8), part);
            partTransition.setFromX(-200);
            partTransition.setToX(200);
            partTransition.setCycleCount(Animation.INDEFINITE);
            partTransition.setAutoReverse(true);
            partTransition.play();
        }

        return new Group(body, wheel1, wheel2, roof, window1, window2);
    }
    private Group createVehicleIcon() {
        // Car body (red color)
        Rectangle body = new Rectangle(150, 60);
        body.setFill(Color.rgb(231, 76, 60));  // Bright red color
        body.setArcWidth(20);
        body.setArcHeight(20);

        // Windows (lighter shade)
        Polygon frontWindow = new Polygon(40, 20, 80, 20, 70, 40, 40, 40);
        frontWindow.setFill(Color.rgb(255, 255, 255, 0.7));

        Polygon rearWindow = new Polygon(80, 20, 120, 20, 110, 40, 80, 40);
        rearWindow.setFill(Color.rgb(255, 255, 255, 0.7));

        // Wheels (black with gray rim)
        Circle frontWheel = new Circle(40, 60, 12, Color.BLACK);
        Circle frontWheelRim = new Circle(40, 60, 8, Color.GRAY);

        Circle rearWheel = new Circle(110, 60, 12, Color.BLACK);
        Circle rearWheelRim = new Circle(110, 60, 8, Color.GRAY);

        // Headlight (yellow)
        Circle headlight = new Circle(130, 40, 5, Color.YELLOW);
        headlight.setEffect(new Glow(0.8));

        // Create the complete vehicle
        Group vehicle = new Group(body, frontWindow, rearWindow,
                frontWheel, frontWheelRim,
                rearWheel, rearWheelRim, headlight);

        // Add shadow effect
        vehicle.setEffect(new DropShadow(10, Color.rgb(0, 0, 0, 0.5)));

        // Create smooth moving animation
        TranslateTransition moveTransition = new TranslateTransition(Duration.seconds(8), vehicle);
        moveTransition.setFromX(-200);
        moveTransition.setToX(800);  // Move from left to right of screen
        moveTransition.setCycleCount(Animation.INDEFINITE);
        moveTransition.setInterpolator(Interpolator.LINEAR);

        // Add slight up-down motion while moving
        Path path = new Path();
        path.getElements().add(new MoveTo(0, 0));
        path.getElements().add(new CubicCurveTo(200, -10, 400, 10, 600, 0));

        PathTransition pathTransition = new PathTransition(Duration.seconds(8), path, vehicle);
        pathTransition.setCycleCount(Animation.INDEFINITE);

        // Combine animations
        ParallelTransition parallelTransition = new ParallelTransition();
        parallelTransition.getChildren().addAll(moveTransition, pathTransition);
        parallelTransition.play();

        return vehicle;
    }
    private void showVehiclePage(Stage primaryStage) {
        BorderPane root = (BorderPane) primaryStage.getScene().getRoot();
        root.setCenter(createVehicleTab());
    }
    private Node createVehicleTab() {
        VBox vehicleLayout = new VBox(10);
        vehicleLayout.setPadding(new javafx.geometry.Insets(20));

        // Set a nice gradient background
        vehicleLayout.setStyle(
                "-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #4CAF50, #8BC34A);");  // Green gradient

        initializeVehicleTable();

        vehicleList.clear();
        loadVehicles();
        vehicleTable.setItems(vehicleList);

        HBox searchBox = createSearchBox();
        vehicleLayout.getChildren().addAll(searchBox, vehicleTable);

        HBox vehicleButtons = createVehicleButtons();
        vehicleLayout.getChildren().addAll(vehicleButtons);
        return vehicleLayout;
    }

    private void initializeVehicleTable() {
        vehicleTable.getColumns().clear();

        TableColumn<Vehicle, String> idColumn = new TableColumn<>("Vehicle ID");
        idColumn.setCellValueFactory(cellData -> cellData.getValue().vehicleIdProperty());

        TableColumn<Vehicle, String> brandColumn = new TableColumn<>("Brand");
        brandColumn.setCellValueFactory(cellData -> cellData.getValue().brandProperty());

        TableColumn<Vehicle, String> modelColumn = new TableColumn<>("Model");
        modelColumn.setCellValueFactory(cellData -> cellData.getValue().modelProperty());

        TableColumn<Vehicle, String> categoryColumn = new TableColumn<>("Category");
        categoryColumn.setCellValueFactory(cellData -> cellData.getValue().categoryProperty());

        TableColumn<Vehicle, String> rentalPriceColumn = new TableColumn<>("Rental Price");
        rentalPriceColumn.setCellValueFactory(cellData -> cellData.getValue().rentalPriceProperty());

        TableColumn<Vehicle, String> availabilityColumn = new TableColumn<>("Available");
        availabilityColumn.setCellValueFactory(cellData -> new SimpleStringProperty(
                cellData.getValue().isAvailable() ? "Yes" : "No"));

        vehicleTable.getColumns().addAll(idColumn, brandColumn, modelColumn, categoryColumn, rentalPriceColumn, availabilityColumn);
    }

    private HBox createSearchBox() {
        HBox searchBox = new HBox(10);
        searchBox.setPadding(new Insets(10));
        searchBox.setAlignment(Pos.CENTER_LEFT);

        TextField searchField = new TextField();
        searchField.setPromptText("Search Vehicles");
        searchField.setPrefWidth(200);

        // Create Search and Reset buttons with text
        Button searchButton = new Button("Search");
        Button resetButton = new Button("Reset");

        // Apply styles to the buttons
        styleButton(searchButton);
        styleButton(resetButton);

        // Add hover animation
        addHoverAnimation(searchButton);
        addHoverAnimation(resetButton);

        // Search button logic
        searchButton.setOnAction(event -> {
            String searchText = searchField.getText().trim().toLowerCase();
            ObservableList<Vehicle> filteredList = FXCollections.observableArrayList();

            for (Vehicle vehicle : vehicleList) {
                if (vehicle.getBrand().toLowerCase().contains(searchText) ||
                        vehicle.getModel().toLowerCase().contains(searchText) ||
                        vehicle.getCategory().toLowerCase().contains(searchText)) {
                    filteredList.add(vehicle);
                }
            }

            if (filteredList.isEmpty()) {
                showAlert("Search Result", "No vehicles found.");
            }

            vehicleTable.setItems(filteredList);
            searchField.clear();
        });

        // Reset button logic
        resetButton.setOnAction(event -> {
            vehicleTable.setItems(vehicleList);
            searchField.clear();
        });

        searchBox.getChildren().addAll(searchField, searchButton, resetButton);
        return searchBox;
    }

    // Simple hover animation for buttons
    private void addHoverAnimation(Button button) {
        button.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
            st.setToX(1.05);
            st.setToY(1.05);
            st.play();
        });

        button.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
            st.setToX(1.0);
            st.setToY(1.0);
            st.play();
        });
    }


    private HBox createVehicleButtons() {
        HBox vehicleButtons = new HBox(10);

        // Buttons with inline CSS styles
        Button addButton = new Button("Add Vehicle");
        styleButton(addButton);

        Button editButton = new Button("Edit Vehicle");
        styleButton(editButton);

        Button deleteButton = new Button("Delete Vehicle");
        styleButton(deleteButton);

        addButton.setOnAction(event -> showAddVehicleDialog());
        editButton.setOnAction(event -> showEditVehicleDialog());
        deleteButton.setOnAction(event -> deleteSelectedVehicle());

        vehicleButtons.getChildren().addAll(addButton, editButton, deleteButton);
        return vehicleButtons;
    }

    private void styleButton(Button button) {
        button.setStyle("-fx-background-color: #007BFF; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10px; -fx-background-radius: 5; -fx-border-color: #0056b3; -fx-border-radius: 5;");
    }

    private void showAddVehicleDialog() {
        Dialog<ButtonType> addDialog = new Dialog<>();
        addDialog.setTitle("Add Vehicle");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));  // Add padding for better appearance

        TextField vehicleIdField = new TextField();
        TextField brandField = new TextField();
        TextField modelField = new TextField();
        TextField categoryField = new TextField();
        TextField rentalPriceField = new TextField();
        CheckBox availableCheckBox = new CheckBox("Available");
        availableCheckBox.setSelected(true);

        grid.add(new Label("Vehicle ID:"), 0, 0);
        grid.add(vehicleIdField, 1, 0);
        grid.add(new Label("Brand:"), 0, 1);
        grid.add(brandField, 1, 1);
        grid.add(new Label("Model:"), 0, 2);
        grid.add(modelField, 1, 2);
        grid.add(new Label("Category:"), 0, 3);
        grid.add(categoryField, 1, 3);
        grid.add(new Label("Rental Price:"), 0, 4);
        grid.add(rentalPriceField, 1, 4);
        grid.add(new Label("Availability:"), 0, 5);
        grid.add(availableCheckBox, 1, 5);

        addDialog.getDialogPane().setContent(grid);

        // Adding buttons to the dialog
        ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        addDialog.getDialogPane().getButtonTypes().addAll(okButton, cancelButton);

        // Styling dialog buttons
        ((Button) addDialog.getDialogPane().lookupButton(okButton)).setStyle("-fx-background-color: #007BFF; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10px; -fx-background-radius: 5;");
        ((Button) addDialog.getDialogPane().lookupButton(cancelButton)).setStyle("-fx-background-color: #dc3545; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10px; -fx-background-radius: 5;");

        // Request focus on the first field
        Platform.runLater(vehicleIdField::requestFocus);

        Optional<ButtonType> result = addDialog.showAndWait();
        if (result.isPresent() && result.get() == okButton) {
            try {
                // Validate inputs
                if (vehicleIdField.getText().isEmpty() || brandField.getText().isEmpty() ||
                        modelField.getText().isEmpty() || categoryField.getText().isEmpty() ||
                        rentalPriceField.getText().isEmpty()) {
                    showAlert("Input Error", "Please fill in all fields.");
                    return;
                }

                // Create and add the vehicle
                Vehicle vehicle = new Vehicle(
                        vehicleIdField.getText(),
                        brandField.getText(),
                        modelField.getText(),
                        categoryField.getText(),
                        rentalPriceField.getText(),
                        availableCheckBox.isSelected());

                addVehicle(vehicle);

                // Refresh the table directly instead of reloading from database
                vehicleList.add(vehicle);
                vehicleTable.refresh();  // Refresh the table view

            } catch (NumberFormatException e) {
                showAlert("Input Error", "Please enter a valid rental price (numeric value).");
            }
        }
    }

    private void addVehicle(Vehicle vehicle) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(
                     "INSERT INTO vehicles (vehicleId, brand, model, category, rentalPrice, availability) VALUES (?, ?, ?, ?, ?, ?)")) {

            pstmt.setString(1, vehicle.getVehicleId());
            pstmt.setString(2, vehicle.getBrand());
            pstmt.setString(3, vehicle.getModel());
            pstmt.setString(4, vehicle.getCategory());
            pstmt.setDouble(5, Double.parseDouble(vehicle.getRentalPrice()));
            pstmt.setBoolean(6, vehicle.isAvailable());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to add vehicle: " + e.getMessage());
        }
    }

    private void showEditVehicleDialog() {
        Vehicle selectedVehicle = vehicleTable.getSelectionModel().getSelectedItem();
        if (selectedVehicle == null) {
            showAlert("Selection Error", "Please select a vehicle to edit.");
            return;
        }

        Dialog<ButtonType> editDialog = new Dialog<>();
        editDialog.setTitle("Edit Vehicle");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        TextField vehicleIdField = new TextField(selectedVehicle.getVehicleId());
        vehicleIdField.setDisable(true);
        TextField brandField = new TextField(selectedVehicle.getBrand());
        TextField modelField = new TextField(selectedVehicle.getModel());
        TextField categoryField = new TextField(selectedVehicle.getCategory());
        TextField rentalPriceField = new TextField(selectedVehicle.getRentalPrice());
        CheckBox availableCheckBox = new CheckBox("Available");
        availableCheckBox.setSelected(selectedVehicle.isAvailable());

        grid.add(new Label("Vehicle ID:"), 0, 0);
        grid.add(vehicleIdField, 1, 0);
        grid.add(new Label("Brand:"), 0, 1);
        grid.add(brandField, 1, 1);
        grid.add(new Label("Model:"), 0, 2);
        grid.add(modelField, 1, 2);
        grid.add(new Label("Category:"), 0, 3);
        grid.add(categoryField, 1, 3);
        grid.add(new Label("Rental Price:"), 0, 4);
        grid.add(rentalPriceField, 1, 4);
        grid.add(new Label("Availability:"), 0, 5);
        grid.add(availableCheckBox, 1, 5);

        editDialog.getDialogPane().setContent(grid);
        editDialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        // Styling the buttons
        Button okButton = (Button) editDialog.getDialogPane().lookupButton(ButtonType.OK);
        Button cancelButton = (Button) editDialog.getDialogPane().lookupButton(ButtonType.CANCEL);

        // Set inline styles for buttons
        okButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10px;");
        cancelButton.setStyle("-fx-background-color: #F44336; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10px;");

        Optional<ButtonType> result = editDialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                String sql = "UPDATE vehicles SET brand=?, model=?, category=?, rentalPrice=?, availability=? WHERE vehicleId=?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, brandField.getText());
                pstmt.setString(2, modelField.getText());
                pstmt.setString(3, categoryField.getText());
                pstmt.setDouble(4, Double.parseDouble(rentalPriceField.getText()));
                pstmt.setBoolean(5, availableCheckBox.isSelected());
                pstmt.setString(6, selectedVehicle.getVehicleId());
                pstmt.executeUpdate();
                pstmt.close();
                conn.close();
                loadVehicles();
            } catch (Exception e) {
                showAlert("Database Error", "Failed to update vehicle: " + e.getMessage());
            }
        }
    }
    private void deleteSelectedVehicle() {
        Vehicle selectedVehicle = vehicleTable.getSelectionModel().getSelectedItem();
        if (selectedVehicle == null) {
            showAlert("Selection Error", "No vehicle selected for deletion.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirm Deletion");
        confirm.setHeaderText(null);
        confirm.setContentText("Are you sure you want to delete vehicle " + selectedVehicle.getVehicleId() + "?");

        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                 PreparedStatement pstmt = conn.prepareStatement("DELETE FROM vehicles WHERE vehicleId = ?")) {

                pstmt.setString(1, selectedVehicle.getVehicleId());
                pstmt.executeUpdate();
                loadVehicles();
            } catch (SQLException e) {
                showAlert("Database Error", "Failed to delete the vehicle: " + e.getMessage());
            }
        }
    }

    private void showCustomerPage(Stage primaryStage) {
        BorderPane root = (BorderPane) primaryStage.getScene().getRoot();
        root.setCenter(createCustomerTab());
    }
    private Node createCustomerTab() {
        // Main container with improved gradient and padding
        VBox customerLayout = new VBox(15);
        customerLayout.setPadding(new Insets(25));
        customerLayout.setStyle("-fx-background-color: linear-gradient(to bottom right, #2196F3, #64B5F6, #BBDEFB);");

        // Title with animation
        Label titleLabel = new Label("Customer Management");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #0D47A1;");

        // Add pulse animation to title
        ScaleTransition titleAnimation = new ScaleTransition(Duration.seconds(2), titleLabel);
        titleAnimation.setFromX(1.0);
        titleAnimation.setFromY(1.0);
        titleAnimation.setToX(1.05);
        titleAnimation.setToY(1.05);
        titleAnimation.setCycleCount(Animation.INDEFINITE);
        titleAnimation.setAutoReverse(true);
        titleAnimation.play();

        // Configure table with modern styling
        customerTable.getColumns().clear();
        customerTable.setStyle("-fx-font-size: 14px; -fx-background-color: transparent;");
        customerTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // Create columns with better styling
        TableColumn<Customer, String> idColumn = createStyledColumn("Customer ID", cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getId())));

        TableColumn<Customer, String> nameColumn = createStyledColumn("Name",
                cellData -> cellData.getValue().nameProperty());

        TableColumn<Customer, String> contactColumn = createStyledColumn("Contact Info",
                cellData -> cellData.getValue().contactInfoProperty());

        TableColumn<Customer, String> licenseColumn = createStyledColumn("Driving License",
                cellData -> cellData.getValue().drivingLicenseProperty());

        customerTable.getColumns().addAll(idColumn, nameColumn, contactColumn, licenseColumn);

        // Load data with fade-in animation
        FadeTransition fadeIn = new FadeTransition(Duration.seconds(0.5), customerTable);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);

        customerList.clear();
        loadCustomers();
        customerTable.setItems(customerList);
        fadeIn.play();

        // Create button panel with improved styling
        HBox customerButtons = new HBox(15);
        customerButtons.setAlignment(Pos.CENTER);

        Button addCustomerButton = createActionButton("Add Customer", "#4CAF50");
        Button editCustomerButton = createActionButton("Edit Customer", "#FF9800");
        Button deleteCustomerButton = createActionButton("Delete Customer", "#F44336");

        // Add button hover animations
        setupButtonHoverEffect(addCustomerButton);
        setupButtonHoverEffect(editCustomerButton);
        setupButtonHoverEffect(deleteCustomerButton);

        // Maintain existing functionality
        addCustomerButton.setOnAction(event -> showAddCustomerDialog());
        editCustomerButton.setOnAction(event -> showEditCustomerDialog());
        deleteCustomerButton.setOnAction(event -> deleteSelectedCustomer());

        customerButtons.getChildren().addAll(addCustomerButton, editCustomerButton, deleteCustomerButton);

        // Add search functionality
        TextField searchField = new TextField();
        searchField.setPromptText("Search customers...");
        searchField.setStyle("-fx-font-size: 14px; -fx-padding: 8px; -fx-background-radius: 5;");

        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            filterCustomers(newValue);
        });

        // Add all components to layout
        customerLayout.getChildren().addAll(titleLabel, searchField, customerTable, customerButtons);
        customerLayout.setAlignment(Pos.TOP_CENTER);

        return customerLayout;
    }

    // Helper method to create styled columns
    private TableColumn<Customer, String> createStyledColumn(String title,
                                                             Callback<TableColumn.CellDataFeatures<Customer, String>, ObservableValue<String>> valueFactory) {

        TableColumn<Customer, String> column = new TableColumn<>(title);
        column.setCellValueFactory(valueFactory);

        // Style the column header
        column.setStyle("-fx-font-weight: bold; -fx-text-fill: #0D47A1;");

        // Style the cells
        column.setCellFactory(tc -> new TableCell<Customer, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(item);
                    setStyle("-fx-border-color: transparent transparent #E3F2FD transparent;");
                }
            }
        });

        return column;
    }

    // Helper method to create styled buttons
    private Button createActionButton(String text, String color) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: " + color + "; " +
                "-fx-text-fill: white; " +
                "-fx-font-weight: bold; " +
                "-fx-font-size: 14px; " +
                "-fx-padding: 10px 20px; " +
                "-fx-background-radius: 5px;");
        return button;
    }

    // Helper method for button hover effects
    private void setupButtonHoverEffect(Button button) {
        final String originalStyle = button.getStyle();
        final String hoverStyle = originalStyle + "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 5, 0, 0, 0);";

        button.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(100), button);
            st.setToX(1.05);
            st.setToY(1.05);
            st.play();
            button.setStyle(hoverStyle);
        });

        button.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(100), button);
            st.setToX(1.0);
            st.setToY(1.0);
            st.play();
            button.setStyle(originalStyle);
        });
    }

    // Helper method for filtering customers
    private HBox createCustomerSearchBox() {
        HBox searchBox = new HBox(10);
        searchBox.setPadding(new Insets(10));
        searchBox.setAlignment(Pos.CENTER_LEFT);

        TextField searchField = new TextField();
        searchField.setPromptText("Search Customers");
        searchField.setPrefWidth(200);

        // Create Search and Reset buttons with text
        Button searchButton = new Button("Search");
        Button resetButton = new Button("Reset");

        // Apply styles to the buttons
        styleButton(searchButton);
        styleButton(resetButton);

        // Add hover animation to buttons
        addHoverAnimation(searchButton);
        addHoverAnimation(resetButton);

        // Search button logic
        searchButton.setOnAction(event -> {
            String searchText = searchField.getText().trim();
            filterCustomers(searchText); // Call the filter method with the search text
        });

        // Reset button logic
        resetButton.setOnAction(event -> {
            searchField.clear(); // Clear the search field
            customerTable.setItems(customerList); // Reset the customer table to show all items
        });

        searchBox.getChildren().addAll(searchField, searchButton, resetButton);
        return searchBox;
    }

    // This method filters the customer list based on the search text
    private void filterCustomers(String searchText) {
        if (searchText == null || searchText.isEmpty()) {
            customerTable.setItems(customerList); // If search text is empty, show all customers
        } else {
            FilteredList<Customer> filteredData = new FilteredList<>(customerList);
            filteredData.setPredicate(customer -> {
                String lowerCaseFilter = searchText.toLowerCase();
                return customer.getName().toLowerCase().contains(lowerCaseFilter) ||
                        customer.getContactInfo().toLowerCase().contains(lowerCaseFilter) ||
                        customer.getDrivingLicense().toLowerCase().contains(lowerCaseFilter) ||
                        String.valueOf(customer.getId()).contains(lowerCaseFilter);
            });
            customerTable.setItems(filteredData); // Set filtered list to the table
        }
    }

    // Helper method to style the buttons
    private void styleBbutton(Button button) {
        button.setStyle("-fx-font-size: 14px; -fx-padding: 5px 10px;");
    }

    // Simple hover animation for buttons
    private void addHoverAnimaation(Button button) {
        button.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
            st.setToX(1.05);
            st.setToY(1.05);
            st.play();
        });

        button.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
            st.setToX(1.0);
            st.setToY(1.0);
            st.play();
        });
    }

    private void showAddCustomerDialog() {
        Dialog<ButtonType> addDialog = new Dialog<>();
        addDialog.setTitle("Add Customer");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        TextField idField = new TextField();
        TextField nameField = new TextField();
        TextField contactField = new TextField();
        TextField licenseField = new TextField();

        grid.add(new Label("Customer ID:"), 0, 0);
        grid.add(idField, 1, 0);
        grid.add(new Label("Name:"), 0, 1);
        grid.add(nameField, 1, 1);
        grid.add(new Label("Contact Info:"), 0, 2);
        grid.add(contactField, 1, 2);
        grid.add(new Label("Driving License:"), 0, 3);
        grid.add(licenseField, 1, 3);

        addDialog.getDialogPane().setContent(grid);
        addDialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Optional<ButtonType> result = addDialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                int customerId = Integer.parseInt(idField.getText().trim());
                addCustomer(new Customer(customerId, nameField.getText(), contactField.getText(), licenseField.getText()));
                loadCustomers();
            } catch (NumberFormatException e) {
                showAlert("Input Error", "Please enter a valid Customer ID.");
            }
        }
    }

    private void addCustomer(Customer customer) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(
                     "INSERT INTO customers (customerId, name, contactInfo, drivingLicense) VALUES (?, ?, ?, ?)")) {

            pstmt.setInt(1, customer.getId());
            pstmt.setString(2, customer.getName());
            pstmt.setString(3, customer.getContactInfo());
            pstmt.setString(4, customer.getDrivingLicense());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to add customer: " + e.getMessage());
        }
    }

    private void showEditCustomerDialog() {
        Customer selectedCustomer = customerTable.getSelectionModel().getSelectedItem();
        if (selectedCustomer == null) {
            showAlert("Selection Error", "Please select a customer to edit.");
            return;
        }

        Dialog<ButtonType> editDialog = new Dialog<>();
        editDialog.setTitle("Edit Customer");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        TextField idField = new TextField(String.valueOf(selectedCustomer.getId()));
        idField.setDisable(true);
        TextField nameField = new TextField(selectedCustomer.getName());
        TextField contactField = new TextField(selectedCustomer.getContactInfo());
        TextField licenseField = new TextField(selectedCustomer.getDrivingLicense());

        grid.add(new Label("Customer ID:"), 0, 0);
        grid.add(idField, 1, 0);
        grid.add(new Label("Name:"), 0, 1);
        grid.add(nameField, 1, 1);
        grid.add(new Label("Contact Info:"), 0, 2);
        grid.add(contactField, 1, 2);
        grid.add(new Label("Driving License:"), 0, 3);
        grid.add(licenseField, 1, 3);

        editDialog.getDialogPane().setContent(grid);
        editDialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Optional<ButtonType> result = editDialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                 PreparedStatement pstmt = conn.prepareStatement(
                         "UPDATE customers SET name=?, contactInfo=?, drivingLicense=? WHERE customerId=?")) {

                pstmt.setString(1, nameField.getText());
                pstmt.setString(2, contactField.getText());
                pstmt.setString(3, licenseField.getText());
                pstmt.setInt(4, selectedCustomer.getId());
                pstmt.executeUpdate();
                loadCustomers();
            } catch (SQLException e) {
                showAlert("Database Error", "Failed to update customer: " + e.getMessage());
            }
        }
    }

    private void deleteSelectedCustomer() {
        Customer selectedCustomer = customerTable.getSelectionModel().getSelectedItem();
        if (selectedCustomer == null) {
            showAlert("Selection Error", "No customer selected for deletion.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirm Deletion");
        confirm.setHeaderText(null);
        confirm.setContentText("Are you sure you want to delete customer " + selectedCustomer.getName() + "?");

        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                 PreparedStatement pstmt = conn.prepareStatement("DELETE FROM customers WHERE customerId = ?")) {

                pstmt.setInt(1, selectedCustomer.getId());
                pstmt.executeUpdate();
                loadCustomers();
            } catch (SQLException e) {
                showAlert("Database Error", "Failed to delete the customer: " + e.getMessage());
            }
        }
    }

    private void showBookingPage(Stage primaryStage) {
        BorderPane root = (BorderPane) primaryStage.getScene().getRoot();
        root.setCenter(createBookingTab());
    }

    private Node createBookingTab() {
        VBox bookingLayout = new VBox(10);
        bookingLayout.setPadding(new javafx.geometry.Insets(20));

        // Set a solid color background for the VBox
        bookingLayout.setStyle(
                "-fx-background-color: #E0F7FA;");  // Light cyan color

        bookingTable.getColumns().clear();

        TableColumn<Booking, String> bookingIdColumn = new TableColumn<>("Booking ID");
        bookingIdColumn.setCellValueFactory(cellData -> cellData.getValue().bookingIdProperty());

        TableColumn<Booking, String> customerIdColumn = new TableColumn<>("Customer ID");
        customerIdColumn.setCellValueFactory(cellData -> cellData.getValue().customerIdProperty());

        TableColumn<Booking, String> vehicleIdColumn = new TableColumn<>("Vehicle ID");
        vehicleIdColumn.setCellValueFactory(cellData -> cellData.getValue().vehicleIdProperty());

        TableColumn<Booking, String> startDateColumn = new TableColumn<>("Start Date");
        startDateColumn.setCellValueFactory(cellData -> cellData.getValue().startDateProperty());

        TableColumn<Booking, String> endDateColumn = new TableColumn<>("End Date");
        endDateColumn.setCellValueFactory(cellData -> cellData.getValue().endDateProperty());

        bookingTable.getColumns().addAll(bookingIdColumn, customerIdColumn, vehicleIdColumn, startDateColumn, endDateColumn);

        bookingList.clear();
        loadBookings();
        bookingTable.setItems(bookingList);

        HBox bookingButtons = new HBox(10); // Add spacing between buttons
        Button addBookingButton = new Button("Add Booking");
        Button cancelBookingButton = new Button("Cancel Booking");

        // Set styles for buttons
        addBookingButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10px;");
        cancelBookingButton.setStyle("-fx-background-color: #F44336; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10px;");

        addBookingButton.setOnAction(event -> showAddBookingDialog());
        cancelBookingButton.setOnAction(event -> cancelSelectedBooking());

        bookingButtons.getChildren().addAll(addBookingButton, cancelBookingButton);
        bookingLayout.getChildren().addAll(bookingTable, bookingButtons);
        return bookingLayout;
    }
    private void showCustomerBookingPage(Stage primaryStage) {
        BorderPane root = (BorderPane) primaryStage.getScene().getRoot();
        root.setCenter(createCustomerBookingTab());
    }

    private Node createCustomerBookingTab() {
        VBox bookingLayout = new VBox(10);
        bookingLayout.setPadding(new javafx.geometry.Insets(20));

        bookingTable.getColumns().clear();
        TableColumn<Booking, String> bookingIdColumn = new TableColumn<>("Booking ID");
        bookingIdColumn.setCellValueFactory(cellData -> cellData.getValue().bookingIdProperty());

        TableColumn<Booking, String> vehicleIdColumn = new TableColumn<>("Vehicle ID");
        vehicleIdColumn.setCellValueFactory(cellData -> cellData.getValue().vehicleIdProperty());

        TableColumn<Booking, String> startDateColumn = new TableColumn<>("Start Date");
        startDateColumn.setCellValueFactory(cellData -> cellData.getValue().startDateProperty());

        TableColumn<Booking, String> endDateColumn = new TableColumn<>("End Date");
        endDateColumn.setCellValueFactory(cellData -> cellData.getValue().endDateProperty());

        bookingTable.getColumns().addAll(bookingIdColumn, vehicleIdColumn, startDateColumn, endDateColumn);

        bookingList.clear();
        loadCustomerBookings();
        bookingTable.setItems(bookingList);

        HBox bookingButtons = new HBox();
        Button addBookingButton = new Button("Add Booking");
        Button cancelBookingButton = new Button("Cancel Booking");

        addBookingButton.setOnAction(event -> showAddBookingDialog());
        cancelBookingButton.setOnAction(event -> cancelSelectedBooking());

        bookingButtons.getChildren().addAll(addBookingButton, cancelBookingButton);
        bookingLayout.getChildren().addAll(bookingTable, bookingButtons);
        return bookingLayout;
    }

    private void loadCustomerBookings() {
        bookingList.clear();
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM bookings WHERE customerId = ?")) {
            stmt.setInt(1, Integer.parseInt(loggedInUserId));
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Booking booking = new Booking(
                        String.valueOf(rs.getInt("bookingId")),
                        String.valueOf(rs.getInt("customerId")),
                        rs.getString("vehicleId"),
                        rs.getDate("startDate").toString(),
                        rs.getDate("endDate").toString());
                bookingList.add(booking);
            }
            bookingTable.setItems(bookingList);
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to load customer bookings: " + e.getMessage());
        }
    }

    private void showAddBookingDialog() {
        if (customerList.isEmpty() || vehicleList.isEmpty()) {
            showAlert("Error", "No customers or vehicles available for booking.");
            return;
        }

        Dialog<ButtonType> bookingDialog = new Dialog<>();
        bookingDialog.setTitle("Book Vehicle");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        TextField bookingIdField = new TextField();

        ComboBox<String> customerComboBox = new ComboBox<>();
        customerComboBox.getItems().addAll(customerList.stream()
                .map(customer -> String.valueOf(customer.getId()))
                .toList());
        customerComboBox.setPromptText("Select Customer ID");

        ComboBox<String> vehicleComboBox = new ComboBox<>();
        vehicleComboBox.getItems().addAll(vehicleList.stream()
                .map(Vehicle::getVehicleId)
                .toList());
        vehicleComboBox.setPromptText("Select Vehicle ID");

        DatePicker startDatePicker = new DatePicker();
        startDatePicker.setValue(LocalDate.now());

        DatePicker endDatePicker = new DatePicker();
        endDatePicker.setValue(LocalDate.now().plusDays(1));

        grid.add(new Label("Booking ID:"), 0, 0);
        grid.add(bookingIdField, 1, 0);
        grid.add(new Label("Customer ID:"), 0, 1);
        grid.add(customerComboBox, 1, 1);
        grid.add(new Label("Vehicle ID:"), 0, 2);
        grid.add(vehicleComboBox, 1, 2);
        grid.add(new Label("Start Date:"), 0, 3);
        grid.add(startDatePicker, 1, 3);
        grid.add(new Label("End Date:"), 0, 4);
        grid.add(endDatePicker, 1, 4);

        bookingDialog.getDialogPane().setContent(grid);
        bookingDialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Optional<ButtonType> result = bookingDialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            String bookingId = bookingIdField.getText().trim();
            String selectedCustomerId = customerComboBox.getValue();
            String selectedVehicleId = vehicleComboBox.getValue();
            LocalDate startDate = startDatePicker.getValue();
            LocalDate endDate = endDatePicker.getValue();

            if (selectedCustomerId == null || selectedVehicleId == null || startDate == null || endDate == null || bookingId.isEmpty()) {
                showAlert("Input Error", "Please fill in all fields.");
                return;
            }

            if (endDate.isBefore(startDate)) {
                showAlert("Date Error", "End date must be after start date.");
                return;
            }

            Vehicle selectedVehicle = vehicleList.stream()
                    .filter(vehicle -> vehicle.getVehicleId().equals(selectedVehicleId))
                    .findFirst()
                    .orElse(null);

            if (selectedVehicle != null && !selectedVehicle.isAvailable()) {
                showAlert("Availability Error", "Selected vehicle is not available.");
                return;
            }

            Booking booking = new Booking(
                    bookingId,
                    selectedCustomerId,
                    selectedVehicleId,
                    startDate.toString(),
                    endDate.toString());

            addBooking(booking);
        }
    }

    private void addBooking(Booking booking) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(
                     "INSERT INTO bookings (bookingId, customerId, vehicleId, startDate, endDate, amount) VALUES (?, ?, ?, ?, ?, ?)")) {

            pstmt.setInt(1, Integer.parseInt(booking.getBookingId()));
            pstmt.setInt(2, Integer.parseInt(booking.getCustomerId()));
            pstmt.setString(3, booking.getVehicleId());
            pstmt.setDate(4, Date.valueOf(booking.getStartDate()));
            pstmt.setDate(5, Date.valueOf(booking.getEndDate()));
            pstmt.setDouble(6, calculateAmount(booking));  // Make sure amount column exists
            pstmt.executeUpdate();

            try (PreparedStatement updateStmt = conn.prepareStatement("UPDATE vehicles SET availability = FALSE WHERE vehicleId = ?")) {
                updateStmt.setString(1, booking.getVehicleId());
                updateStmt.executeUpdate();
            }

            loadBookings();
            loadVehicles();
        } catch (SQLException e) {
            showAlert("Database Error", "An error occurred while adding the booking: " + e.getMessage());
        }
    }

    private double calculateAmount(Booking booking) {
        double rentalPrice = 0;
        for (Vehicle vehicle : vehicleList) {
            if (vehicle.getVehicleId().equals(booking.getVehicleId())) {
                rentalPrice = Double.parseDouble(vehicle.getRentalPrice());
                break;
            }
        }
        LocalDate startDate = LocalDate.parse(booking.getStartDate());
        LocalDate endDate = LocalDate.parse(booking.getEndDate());
        long rentalDays = java.time.temporal.ChronoUnit.DAYS.between(startDate, endDate);
        return rentalPrice * rentalDays;
    }

    private void cancelSelectedBooking() {
        Booking selectedBooking = bookingTable.getSelectionModel().getSelectedItem();
        if (selectedBooking == null) {
            showAlert("Selection Error", "No booking selected for cancellation.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirm Cancellation");
        confirm.setContentText("Are you sure you want to cancel booking " + selectedBooking.getBookingId() + "?");

        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
                conn.setAutoCommit(false);

                try {
                    PreparedStatement deleteStmt = conn.prepareStatement("DELETE FROM bookings WHERE bookingId = ?");
                    deleteStmt.setInt(1, Integer.parseInt(selectedBooking.getBookingId()));
                    deleteStmt.executeUpdate();

                    PreparedStatement updateStmt = conn.prepareStatement("UPDATE vehicles SET availability = TRUE WHERE vehicleId = ?");
                    updateStmt.setString(1, selectedBooking.getVehicleId());
                    updateStmt.executeUpdate();

                    conn.commit();
                    loadBookings();
                    loadVehicles();
                } catch (SQLException e) {
                    conn.rollback();
                    throw e;
                }
            } catch (SQLException e) {
                showAlert("Database Error", "Failed to cancel the booking: " + e.getMessage());
            }
        }
    }

    private void showPaymentPage(Stage primaryStage) {
        BorderPane root = (BorderPane) primaryStage.getScene().getRoot();
        root.setCenter(createPaymentTab());
    }
    private Node createPaymentTab() {
        VBox paymentLayout = new VBox(10);
        paymentLayout.setPadding(new javafx.geometry.Insets(20));
        paymentLayout.setAlignment(Pos.TOP_CENTER);

        // Stylish gradient background with animation
        paymentLayout.setStyle(
                "-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #2c3e50, #3498db);" +
                        "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 10, 0, 0, 0);"
        );

        // Create a floating money icon
        Label moneyIcon = new Label("💰");
        moneyIcon.setStyle("-fx-font-size: 36px; -fx-opacity: 0.8;");


        // Animation for the money icon
        TranslateTransition floatAnimation = new TranslateTransition(Duration.seconds(15), moneyIcon);
        floatAnimation.setFromX(-200);
        floatAnimation.setToX(200);
        floatAnimation.setFromY(-100);
        floatAnimation.setToY(100);
        floatAnimation.setCycleCount(Animation.INDEFINITE);
        floatAnimation.setAutoReverse(true);
        floatAnimation.setInterpolator(Interpolator.EASE_BOTH);
        floatAnimation.play();

        // StackPane to overlay the icon on the table
        StackPane tableContainer = new StackPane();
        tableContainer.getChildren().addAll(paymentTable, moneyIcon);
        StackPane.setAlignment(moneyIcon, Pos.TOP_LEFT);

        paymentTable.getColumns().clear();

        // Define table columns with stylish headers
        String columnStyle = "-fx-font-weight: bold; -fx-text-fill: #2c3e50; -fx-font-size: 14px;";

        TableColumn<Payment, String> paymentIdColumn = new TableColumn<>("Payment ID");
        paymentIdColumn.setCellValueFactory(cellData -> cellData.getValue().paymentIdProperty());
        paymentIdColumn.setStyle(columnStyle);

        TableColumn<Payment, String> bookingIdColumn = new TableColumn<>("Booking ID");
        bookingIdColumn.setCellValueFactory(cellData -> cellData.getValue().bookingIdProperty());
        bookingIdColumn.setStyle(columnStyle);

        TableColumn<Payment, String> amountColumn = new TableColumn<>("Amount");
        amountColumn.setCellValueFactory(cellData -> cellData.getValue().amountProperty());
        amountColumn.setStyle(columnStyle);

        TableColumn<Payment, String> paymentDateColumn = new TableColumn<>("Payment Date");
        paymentDateColumn.setCellValueFactory(cellData -> cellData.getValue().paymentDateProperty());
        paymentDateColumn.setStyle(columnStyle);

        TableColumn<Payment, String> methodColumn = new TableColumn<>("Payment Method");
        methodColumn.setCellValueFactory(cellData -> cellData.getValue().paymentMethodProperty());
        methodColumn.setStyle(columnStyle);

        paymentTable.getColumns().addAll(paymentIdColumn, bookingIdColumn, amountColumn, paymentDateColumn, methodColumn);

        // Style the table
        paymentTable.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-background-color: rgba(255, 255, 255, 0.9);" +
                        "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 5, 0, 0, 0);"
        );

        // Alternate row coloring
        paymentTable.setRowFactory(tv -> new TableRow<Payment>() {
            @Override
            protected void updateItem(Payment item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setStyle("");
                } else {
                    if (getIndex() % 2 == 0) {
                        setStyle("-fx-background-color: #f8f9fa;");
                    } else {
                        setStyle("-fx-background-color: #e9ecef;");
                    }
                }
            }
        });

        paymentList.clear();
        loadPayments();
        paymentTable.setItems(paymentList);

        // Create the buttons for payments with hover effects
        HBox paymentButtons = new HBox(10);
        paymentButtons.setAlignment(Pos.CENTER);

        String buttonBaseStyle =
                "-fx-font-size: 14px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-padding: 10px 20px;" +
                        "-fx-border-radius: 5px;" +
                        "-fx-background-radius: 5px;" +
                        "-fx-cursor: hand;" +
                        "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 3, 0, 0, 0);" +
                        "-fx-transition: all 0.3s;";

        Button addPaymentButton = createStyledButton("Add Payment", "#2ecc71", "#27ae60", buttonBaseStyle);
        Button deletePaymentButton = createStyledButton("Delete Payment", "#e74c3c", "#c0392b", buttonBaseStyle);
        Button generateInvoiceButton = createStyledButton("Generate Invoice", "#3498db", "#2980b9", buttonBaseStyle);
        Button exportCsvButton = createStyledButton("Export CSV", "#f39c12", "#d35400", buttonBaseStyle);
        Button exportPdfButton = createStyledButton("Export PDF", "#9b59b6", "#8e44ad", buttonBaseStyle);

        // Add button actions
        addPaymentButton.setOnAction(event -> showAddPaymentDialog());
        deletePaymentButton.setOnAction(event -> deleteSelectedPayment());
        generateInvoiceButton.setOnAction(event -> generateInvoice());
        exportCsvButton.setOnAction(event -> exportToCSV());
        exportPdfButton.setOnAction(event -> exportToPDF());

        // Add buttons to the HBox
        paymentButtons.getChildren().addAll(addPaymentButton, deletePaymentButton, generateInvoiceButton, exportCsvButton, exportPdfButton);

        // Add title
        Label title = new Label("Payment Management");
        title.setStyle(
                "-fx-font-size: 24px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: white;" +
                        "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 5, 0, 0, 1);"
        );

        // Add all components to the layout
        paymentLayout.getChildren().addAll(title, tableContainer, paymentButtons);

        // Add subtle pulse animation to the title
        FadeTransition pulse = new FadeTransition(Duration.seconds(2), title);
        pulse.setFromValue(0.8);
        pulse.setToValue(1.0);
        pulse.setCycleCount(Animation.INDEFINITE);
        pulse.setAutoReverse(true);
        pulse.play();

        return paymentLayout;
    }

    private Button createStyledButton(String text, String baseColor, String hoverColor, String baseStyle) {
        Button button = new Button(text);
        button.setStyle(baseStyle + "-fx-background-color: " + baseColor + "; -fx-text-fill: white;");

        button.setOnMouseEntered(e -> button.setStyle(baseStyle + "-fx-background-color: " + hoverColor + "; -fx-text-fill: white; -fx-scale-x: 1.05; -fx-scale-y: 1.05;"));
        button.setOnMouseExited(e -> button.setStyle(baseStyle + "-fx-background-color: " + baseColor + "; -fx-text-fill: white; -fx-scale-x: 1.0; -fx-scale-y: 1.0;"));

        return button;
    }
    private void showAddPaymentDialog() {
        Dialog<ButtonType> paymentDialog = new Dialog<>();
        paymentDialog.setTitle("Add Payment");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        TextField paymentIdField = new TextField();

        ComboBox<String> bookingComboBox = new ComboBox<>();
        bookingComboBox.getItems().addAll(bookingList.stream()
                .map(Booking::getBookingId)
                .toList());
        bookingComboBox.setPromptText("Select Booking ID");

        TextField amountField = new TextField();
        ComboBox<String> paymentMethodComboBox = new ComboBox<>();
        paymentMethodComboBox.getItems().addAll("Cash", "Credit Card", "Online");
        paymentMethodComboBox.setValue("Cash");

        grid.add(new Label("Payment ID:"), 0, 0);
        grid.add(paymentIdField, 1, 0);
        grid.add(new Label("Booking ID:"), 0, 1);
        grid.add(bookingComboBox, 1, 1);
        grid.add(new Label("Amount:"), 0, 2);
        grid.add(amountField, 1, 2);
        grid.add(new Label("Payment Method:"), 0, 3);
        grid.add(paymentMethodComboBox, 1, 3);

        paymentDialog.getDialogPane().setContent(grid);
        paymentDialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Optional<ButtonType> result = paymentDialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            String selectedBookingId = bookingComboBox.getValue();
            if (selectedBookingId == null || paymentIdField.getText().trim().isEmpty() || amountField.getText().trim().isEmpty()) {
                showAlert("Input Error", "Please fill in all fields.");
                return;
            }

            Payment payment = new Payment(
                    paymentIdField.getText(),
                    selectedBookingId,
                    amountField.getText(),
                    LocalDate.now().toString(),
                    paymentMethodComboBox.getValue());
            addPayment(payment);
        }
    }

    private void addPayment(Payment payment) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(
                     "INSERT INTO payments (paymentId, bookingId, amount, paymentDate, paymentMethod) VALUES (?, ?, ?, ?, ?)")) {

            pstmt.setInt(1, Integer.parseInt(payment.getPaymentId()));
            pstmt.setInt(2, Integer.parseInt(payment.getBookingId()));
            pstmt.setDouble(3, Double.parseDouble(payment.getAmount()));
            pstmt.setTimestamp(4, Timestamp.valueOf(LocalDate.now().atStartOfDay()));
            pstmt.setString(5, payment.getPaymentMethod());
            pstmt.executeUpdate();
            loadPayments();
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to add payment: " + e.getMessage());
        }
    }

    private void deleteSelectedPayment() {
        Payment selectedPayment = paymentTable.getSelectionModel().getSelectedItem();
        if (selectedPayment == null) {
            showAlert("Selection Error", "No payment selected for deletion.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirm Deletion");
        confirm.setHeaderText(null);
        confirm.setContentText("Are you sure you want to delete payment " + selectedPayment.getPaymentId() + "?");

        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                 PreparedStatement pstmt = conn.prepareStatement("DELETE FROM payments WHERE paymentId = ?")) {

                pstmt.setInt(1, Integer.parseInt(selectedPayment.getPaymentId()));
                pstmt.executeUpdate();
                loadPayments();
            } catch (SQLException e) {
                showAlert("Database Error", "Failed to delete the payment: " + e.getMessage());
            }
        }
    }

    private void showReportPage(Stage primaryStage) {
        BorderPane root = (BorderPane) primaryStage.getScene().getRoot();
        root.setCenter(createReportTab());
    }

    private Node createReportTab() {
        TabPane reportTabPane = new TabPane();

        Tab availableVehiclesTab = new Tab("Available Vehicles");
        availableVehiclesTab.setContent(createAvailableVehiclesReport());

        Tab rentalHistoryTab = new Tab("Customer Rental History");
        rentalHistoryTab.setContent(createCustomerRentalHistoryReport());

        Tab revenueReportTab = new Tab("Revenue Report");
        revenueReportTab.setContent(createRevenueReport());

        reportTabPane.getTabs().addAll(availableVehiclesTab, rentalHistoryTab, revenueReportTab);

        // Apply styles to the TabPane if needed
        reportTabPane.setStyle("-fx-background-color: #F1F1F1; -fx-font-family: 'Arial';");

        return reportTabPane;
    }
    private VBox createAvailableVehiclesReport() {
        VBox layout = new VBox(10);
        layout.setPadding(new javafx.geometry.Insets(20));

        // Set the background color for the layout
        layout.setStyle("-fx-background-color: #EAEAEA;"); // Light gray background

        Label title = new Label("Available Vehicles Report");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #333333;");
        layout.getChildren().add(title);

        ObservableList<Vehicle> availableVehicles = FXCollections.observableArrayList();
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM vehicles WHERE availability = TRUE");
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Vehicle vehicle = new Vehicle(
                        rs.getString("vehicleId"),
                        rs.getString("brand"),
                        rs.getString("model"),
                        rs.getString("category"),
                        String.valueOf(rs.getDouble("rentalPrice")),
                        rs.getBoolean("availability"));
                availableVehicles.add(vehicle);
            }
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to load available vehicles: " + e.getMessage());
        }

        PieChart pieChart = new PieChart();
        for (Vehicle vehicle : availableVehicles) {
            pieChart.getData().add(new PieChart.Data(vehicle.getCategory(), 1));
        }

        // Create the export button next to the chart
        Button exportCsvButton = new Button("Export CSV");
        exportCsvButton.setOnAction(event -> exportAvailableVehiclesToCSV(availableVehicles));

        HBox chartContainer = new HBox(10, pieChart, exportCsvButton); // Creates a horizontal layout
        layout.getChildren().add(chartContainer);
        return layout;
    }

    private void exportAvailableVehiclesToCSV(ObservableList<Vehicle> availableVehicles) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save CSV File");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        File file = fileChooser.showSaveDialog(null);

        if (file != null) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write("Vehicle ID,Brand,Model,Category,Rental Price,Availability\n");
                for (Vehicle vehicle : availableVehicles) {
                    writer.write(String.format("%s,%s,%s,%s,%s,%b\n",
                            vehicle.getVehicleId(),
                            vehicle.getBrand(),
                            vehicle.getModel(),
                            vehicle.getCategory(),
                            vehicle.getRentalPrice(),
                            vehicle.isAvailable()));
                }
                showAlert("Export Successful", "Available vehicles have been exported to CSV.");

     } catch (Exception e) {
                showAlert("Export Error", "Failed to export to CSV: " + e.getMessage());
            }
        }
    }
    private VBox createCustomerRentalHistoryReport() {
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.setStyle("-fx-background-color: #EAEAEA;");

        Label title = new Label("Customer Rental History");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #333333;");
        layout.getChildren().add(title);

        // Add customer selection components
        HBox customerSelectionBox = new HBox(10);
        Label customerLabel = new Label("Select Customer:");
        ComboBox<String> customerCombo = new ComboBox<>();

        // Populate customer combo box
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT customerId, name FROM customers ORDER BY name")) {

            while (rs.next()) {
                customerCombo.getItems().add(rs.getInt("customerId") + " - " + rs.getString("name"));
            }
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to load customers: " + e.getMessage());
        }

        customerSelectionBox.getChildren().addAll(customerLabel, customerCombo);
        layout.getChildren().add(customerSelectionBox);

        // Create chart
        NumberAxis xAxis = new NumberAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Rental Date (Days)");
        yAxis.setLabel("Rental Count");
        LineChart<Number, Number> lineChart = new LineChart<>(xAxis, yAxis);
        lineChart.setTitle("Rentals Over Time");
        lineChart.setVisible(false);

        // Create table view for detailed history
        TableView<Booking> historyTable = new TableView<>();
        historyTable.setVisible(false);
        historyTable.setPrefHeight(300);

        // Create columns for the table
        TableColumn<Booking, String> idCol = new TableColumn<>("Booking ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("bookingId"));

        TableColumn<Booking, String> vehicleCol = new TableColumn<>("Vehicle ID");
        vehicleCol.setCellValueFactory(new PropertyValueFactory<>("vehicleId"));

        TableColumn<Booking, String> startDateCol = new TableColumn<>("Start Date");
        startDateCol.setCellValueFactory(new PropertyValueFactory<>("startDate"));

        TableColumn<Booking, String> endDateCol = new TableColumn<>("End Date");
        endDateCol.setCellValueFactory(new PropertyValueFactory<>("endDate"));

        TableColumn<Booking, String> durationCol = new TableColumn<>("Duration (Days)");
        durationCol.setCellValueFactory(cellData -> {
            try {
                LocalDate start = LocalDate.parse(cellData.getValue().getStartDate());
                LocalDate end = LocalDate.parse(cellData.getValue().getEndDate());
                long days = ChronoUnit.DAYS.between(start, end);
                return new SimpleStringProperty(String.valueOf(days));
            } catch (Exception e) {
                return new SimpleStringProperty("N/A");
            }
        });

        historyTable.getColumns().addAll(idCol, vehicleCol, startDateCol, endDateCol, durationCol);

        // Create export button
        Button exportCsvButton = new Button("Export CSV");
        exportCsvButton.setDisable(true);
        exportCsvButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");

        // Update chart and table when customer is selected
        customerCombo.valueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                try {
                    int customerId = Integer.parseInt(newVal.split(" - ")[0]);
                    ObservableList<Booking> customerBookings = getCustomerBookings(customerId);

                    // Update chart
                    updateRentalChart(lineChart, customerBookings);
                    lineChart.setVisible(true);

                    // Update table
                    historyTable.setItems(customerBookings);
                    historyTable.setVisible(true);

                    // Enable export button
                    exportCsvButton.setDisable(false);

                    // Set export action for this customer's data
                    exportCsvButton.setOnAction(event ->
                            exportCustomerRentalHistoryToCSV(customerBookings, newVal.split(" - ")[1]));

                } catch (Exception e) {
                    showAlert("Error", "Failed to load customer history: " + e.getMessage());
                }
            }
        });

        // Create container for chart and export button
        HBox topContainer = new HBox(10, lineChart, exportCsvButton);
        topContainer.setAlignment(Pos.CENTER_LEFT);

        VBox chartAndTableContainer = new VBox(10, topContainer, historyTable);
        chartAndTableContainer.setPadding(new Insets(10));

        layout.getChildren().add(chartAndTableContainer);

        return layout;
    }

    private void updateRentalChart(LineChart<Number, Number> lineChart, ObservableList<Booking> customerBookings) {
        lineChart.getData().clear();

        if (customerBookings.isEmpty()) {
            return;
        }

        XYChart.Series<Number, Number> series = new XYChart.Series<>();
        series.setName("Rentals");

        // Group by date to show count per day
        Map<LocalDate, Integer> rentalsPerDay = new HashMap<>();
        for (Booking booking : customerBookings) {
            LocalDate rentalDate = LocalDate.parse(booking.getStartDate());
            rentalsPerDay.put(rentalDate, rentalsPerDay.getOrDefault(rentalDate, 0) + 1);
        }

        // Add data points to series
        for (Map.Entry<LocalDate, Integer> entry : rentalsPerDay.entrySet()) {
            long daysSinceEpoch = entry.getKey().toEpochDay();
            series.getData().add(new XYChart.Data<>(daysSinceEpoch, entry.getValue()));
        }

        lineChart.getData().add(series);
    }

    private ObservableList<Booking> getCustomerBookings(int customerId) {
        ObservableList<Booking> customerBookings = FXCollections.observableArrayList();

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT b.* FROM bookings b " +
                             "WHERE b.customerId = ? ORDER BY b.startDate DESC")) {

            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Booking booking = new Booking(
                        String.valueOf(rs.getInt("bookingId")),
                        String.valueOf(rs.getInt("customerId")),
                        rs.getString("vehicleId"), // Just the vehicle ID without make/model
                        rs.getDate("startDate").toString(),
                        rs.getDate("endDate").toString());
                customerBookings.add(booking);
            }
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to load rental history: " + e.getMessage());
        }

        return customerBookings;
    }
    public class Booking {
        private final StringProperty bookingId = new SimpleStringProperty();
        private final StringProperty customerId = new SimpleStringProperty();
        private final StringProperty vehicleId = new SimpleStringProperty();
        private final StringProperty startDate = new SimpleStringProperty();
        private final StringProperty endDate = new SimpleStringProperty();

        // Constructor
        public Booking(String bookingId, String customerId, String vehicleId, String startDate, String endDate) {
            this.bookingId.set(bookingId);
            this.customerId.set(customerId);
            this.vehicleId.set(vehicleId);
            this.startDate.set(startDate);
            this.endDate.set(endDate);
        }

        // Property getters
        public StringProperty bookingIdProperty() { return bookingId; }
        public StringProperty customerIdProperty() { return customerId; }
        public StringProperty vehicleIdProperty() { return vehicleId; }
        public StringProperty startDateProperty() { return startDate; }
        public StringProperty endDateProperty() { return endDate; }

        // Regular getters
        public String getBookingId() { return bookingId.get(); }
        public String getCustomerId() { return customerId.get(); }
        public String getVehicleId() { return vehicleId.get(); }
        public String getStartDate() { return startDate.get(); }
        public String getEndDate() { return endDate.get(); }
    }
    private void exportCustomerRentalHistoryToCSV(ObservableList<Booking> customerBookings, String customerName) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Customer Rental History");
        fileChooser.setInitialFileName(customerName.replaceAll("[^a-zA-Z0-9]", "_") + "_rental_history.csv");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        File file = fileChooser.showSaveDialog(null);

        if (file != null) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                // Write CSV header
                writer.write("Booking ID,Vehicle ID,Start Date,End Date,Duration (Days)\n");

                // Write each booking
                for (Booking booking : customerBookings) {
                    LocalDate start = LocalDate.parse(booking.getStartDate());
                    LocalDate end = LocalDate.parse(booking.getEndDate());
                    long duration = ChronoUnit.DAYS.between(start, end);

                    writer.write(String.format("\"%s\",\"%s\",\"%s\",\"%s\",\"%d\"\n",
                            booking.getBookingId(),
                            booking.getVehicleId(),
                            booking.getStartDate(),
                            booking.getEndDate(),
                            duration));
                }

                showAlert("Export Successful",
                        String.format("Exported %d rentals to:\n%s", customerBookings.size(), file.getAbsolutePath()));
            } catch (Exception e) {
                showAlert("Export Error", "Failed to export to CSV: " + e.getMessage());
            }
        }
    }
    private VBox createRevenueReport() {
        VBox layout = new VBox(10);
        layout.setPadding(new javafx.geometry.Insets(20));

        Label title = new Label("Revenue Report");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        layout.getChildren().add(title);

        AreaChart<Number, Number> areaChart = new AreaChart<>(new NumberAxis(), new NumberAxis());
        areaChart.setTitle("Revenue Over Time");

        loadRevenueData(areaChart);

        // Create the export button for revenue report
        Button exportCsvButton = new Button("Export CSV");
        exportCsvButton.setOnAction(event -> exportRevenueReportToCSV());

        HBox chartContainer = new HBox(10, areaChart, exportCsvButton); // Creates a horizontal layout
        layout.getChildren().add(chartContainer);
        return layout;
    }

    private void exportRevenueReportToCSV() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save CSV File");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        File file = fileChooser.showSaveDialog(null);

        if (file != null) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write("Month,Total Revenue\n");
                // Assuming revenue data is gathered here
                // You can use the same logic you used in loadRevenueData()
                try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                     PreparedStatement stmt = conn.prepareStatement("SELECT SUM(amount) AS totalRevenue, MONTH(paymentDate) AS month FROM payments GROUP BY month");
                     ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        double totalRevenue = rs.getDouble("totalRevenue");
                        int month = rs.getInt("month");
                        writer.write(String.format("%d,%.2f\n", month, totalRevenue));
                    }
                }
                showAlert("Export Successful", "Revenue report has been exported to CSV.");
            } catch (Exception e) {
                showAlert("Export Error", "Failed to export to CSV: " + e.getMessage());
            }
        }
    }
    private void loadRevenueData(AreaChart<Number, Number> areaChart) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement("SELECT SUM(amount) AS totalRevenue, MONTH(paymentDate) AS month FROM payments GROUP BY month");
             ResultSet rs = stmt.executeQuery()) {
            XYChart.Series<Number, Number> series = new XYChart.Series<>();
            series.setName("Monthly Revenue");

            while (rs.next()) {
                double totalRevenue = rs.getDouble("totalRevenue");
                int month = rs.getInt("month");
                series.getData().add(new XYChart.Data<>(month, totalRevenue));
            }
            areaChart.getData().add(series);
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to load revenue data: " + e.getMessage());
        }
    }

    private void loadVehicles() {
        vehicleList.clear();
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM vehicles");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Vehicle vehicle = new Vehicle(
                        rs.getString("vehicleId"),
                        rs.getString("brand"),
                        rs.getString("model"),
                        rs.getString("category"),
                        String.valueOf(rs.getDouble("rentalPrice")),
                        rs.getBoolean("availability"));
                vehicleList.add(vehicle);
            }
            vehicleTable.setItems(vehicleList);
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to load vehicles: " + e.getMessage());
        }
    }

    private void loadCustomers() {
        customerList.clear();
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM customers");
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Customer customer = new Customer(
                        rs.getInt("customerId"),
                        rs.getString("name"),
                        rs.getString("contactInfo"),
                        rs.getString("drivingLicense"));
                customerList.add(customer);
            }
            customerTable.setItems(customerList);
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to load customers: " + e.getMessage());
        }
    }

    private void loadBookings() {
        bookingList.clear();
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM bookings");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Booking booking = new Booking(
                        String.valueOf(rs.getInt("bookingId")),
                        String.valueOf(rs.getInt("customerId")),
                        rs.getString("vehicleId"),
                        rs.getDate("startDate").toString(),
                        rs.getDate("endDate").toString());
                bookingList.add(booking);
            }
            bookingTable.setItems(bookingList);
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to load bookings: " + e.getMessage());
        }
    }

    private void handleLogout(Stage primaryStage) {
        userRole = null;
        primaryStage.close();
        login(new Stage());
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void generateInvoice() {
        Payment selectedPayment = paymentTable.getSelectionModel().getSelectedItem();
        if (selectedPayment == null) {
            showAlert("Selection Error", "No payment selected for invoice generation.");
            return;
        }

        // Retrieve booking and customer details based on the selected payment
        String bookingId = selectedPayment.getBookingId();
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM bookings WHERE bookingId = ?")) {
            pstmt.setInt(1, Integer.parseInt(bookingId));
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                // Fetch booking details
                String customerId = rs.getString("customerId");
                String vehicleId = rs.getString("vehicleId");
                Date startDate = rs.getDate("startDate");
                Date endDate = rs.getDate("endDate");
                double amount = rs.getDouble("amount");

                // Fetch customer details
                Customer customer = null;
                try (PreparedStatement customerStmt = conn.prepareStatement("SELECT * FROM customers WHERE customerId = ?")) {
                    customerStmt.setInt(1, Integer.parseInt(customerId));
                    ResultSet customerRs = customerStmt.executeQuery();
                    if (customerRs.next()) {
                        customer = new Customer(
                                customerRs.getInt("customerId"),
                                customerRs.getString("name"),
                                customerRs.getString("contactInfo"),
                                customerRs.getString("drivingLicense")
                        );
                    }
                }

                // Fetch vehicle details
                Vehicle vehicle = null;
                try (PreparedStatement vehicleStmt = conn.prepareStatement("SELECT * FROM vehicles WHERE vehicleId = ?")) {
                    vehicleStmt.setString(1, vehicleId);
                    ResultSet vehicleRs = vehicleStmt.executeQuery();
                    if (vehicleRs.next()) {
                        vehicle = new Vehicle(
                                vehicleRs.getString("vehicleId"),
                                vehicleRs.getString("brand"),
                                vehicleRs.getString("model"),
                                vehicleRs.getString("category"),
                                String.valueOf(vehicleRs.getDouble("rentalPrice")),
                                vehicleRs.getBoolean("availability")
                        );
                    }
                }

                // Generate invoice content
                String invoiceContent = String.format(
                        "Invoice Details:\n" +
                                "Booking ID: %s\n" +
                                "Customer Name: %s\n" +
                                "Vehicle: %s\n" +  // Single %s since brand and model are concatenated
                                "Start Date: %s\n" +
                                "End Date: %s\n" +
                                "Total Amount: $%.2f",  // Added $ for currency formatting
                        bookingId,
                        (customer != null ? customer.getName() : "N/A"),
                        (vehicle != null ? vehicle.getBrand() + " " + vehicle.getModel() : "N/A"),
                        startDate,
                        endDate,
                        amount
                );

                // Display invoice in a dialog or save to file
                showAlert("Invoice Generated", invoiceContent);

                // Alternatively, write to a file
                // saveInvoiceToFile(invoiceContent, "invoice_" + bookingId + ".txt");

            } else {
                showAlert("Invoice Error", "No booking found for the selected payment.");
            }
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to generate invoice: " + e.getMessage());
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid booking ID format: " + e.getMessage());
        }
    }

    // Optional: Method to save invoice to a file
    private void saveInvoiceToFile(String content, String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write(content);
            showAlert("Success", "Invoice saved as: " + fileName);
        } catch (IOException e) {
            showAlert("Error", "Failed to save invoice: " + e.getMessage());
        }
    }
    private void exportToCSV() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save CSV File");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        File file = fileChooser.showSaveDialog(null);

        if (file != null) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write("Payment ID, Booking ID, Amount, Payment Date, Payment Method\n");
                for (Payment payment : paymentList) {
                    writer.write(payment.getPaymentId() + "," + payment.getBookingId() + ","
                            + payment.getAmount() + "," + payment.getPaymentDate() + ","
                            + payment.getPaymentMethod() + "\n");
                }
                showAlert("Export Successful", "Payments have been exported to CSV.");
            } catch (Exception e) {
                showAlert("Export Error", "Failed to export to CSV: " + e.getMessage());
            }
        }
    }

    private void exportToPDF() {
        showAlert("PDF Export", "PDF export functionality is not implemented yet.");
    }
}

class Vehicle {
    private SimpleStringProperty vehicleId;
    private SimpleStringProperty brand;
    private SimpleStringProperty model;
    private SimpleStringProperty category;
    private SimpleStringProperty rentalPrice;
    private boolean availability;

    public Vehicle(String vehicleId, String brand, String model, String category, String rentalPrice, boolean availability) {
        this.vehicleId = new SimpleStringProperty(vehicleId);
        this.brand = new SimpleStringProperty(brand);
        this.model = new SimpleStringProperty(model);
        this.category = new SimpleStringProperty(category);
        this.rentalPrice = new SimpleStringProperty(rentalPrice);
        this.availability = availability;
    }

    public SimpleStringProperty vehicleIdProperty() {
        return vehicleId;
    }

    public SimpleStringProperty brandProperty() {
        return brand;
    }

    public SimpleStringProperty modelProperty() {
        return model;
    }

    public SimpleStringProperty categoryProperty() {
        return category;
    }

    public SimpleStringProperty rentalPriceProperty() {
        return rentalPrice;
    }

    public boolean isAvailable() {
        return availability;
    }

    public String getVehicleId() {
        return vehicleId.get();
    }

    public String getBrand() {
        return brand.get();
    }

    public String getModel() {
        return model.get();
    }

    public String getCategory() {
        return category.get();
    }

    public String getRentalPrice() {
        return rentalPrice.get();
    }
}

class Customer {
    private int id;
    private SimpleStringProperty name;
    private SimpleStringProperty contactInfo;
    private SimpleStringProperty drivingLicense;

    public Customer(int id, String name, String contactInfo, String drivingLicense) {
        this.id = id;
        this.name = new SimpleStringProperty(name);
        this.contactInfo = new SimpleStringProperty(contactInfo);
        this.drivingLicense = new SimpleStringProperty(drivingLicense);
    }

    public int getId() {
        return id;
    }

    public SimpleStringProperty nameProperty() {
        return name;
    }

    public SimpleStringProperty contactInfoProperty() {
        return contactInfo;
    }

    public SimpleStringProperty drivingLicenseProperty() {
        return drivingLicense;
    }

    public String getName() {
        return name.get();
    }

    public String getContactInfo() {
        return contactInfo.get();
    }

    public String getDrivingLicense() {
        return drivingLicense.get();
    }
}

class Booking {
    private SimpleStringProperty bookingId;
    private SimpleStringProperty customerId;
    private SimpleStringProperty vehicleId;
    private SimpleStringProperty startDate;
    private SimpleStringProperty endDate;

    public Booking(String bookingId, String customerId, String vehicleId, String startDate, String endDate) {
        this.bookingId = new SimpleStringProperty(bookingId);
        this.customerId = new SimpleStringProperty(customerId);
        this.vehicleId = new SimpleStringProperty(vehicleId);
        this.startDate = new SimpleStringProperty(startDate);
        this.endDate = new SimpleStringProperty(endDate);
    }

    public SimpleStringProperty bookingIdProperty() {
        return bookingId;
    }

    public SimpleStringProperty customerIdProperty() {
        return customerId;
    }

    public SimpleStringProperty vehicleIdProperty() {
        return vehicleId;
    }

    public SimpleStringProperty startDateProperty() {
        return startDate;
    }

    public SimpleStringProperty endDateProperty() {
        return endDate;
    }

    public String getBookingId() {
        return bookingId.get();
    }

    public String getCustomerId() {
        return customerId.get();
    }

    public String getVehicleId() {
        return vehicleId.get();
    }

    public String getStartDate() {
        return startDate.get();
    }

    public String getEndDate() {
        return endDate.get();
    }
}

class Payment {
    private SimpleStringProperty paymentId;
    private SimpleStringProperty bookingId;
    private SimpleStringProperty amount;
    private SimpleStringProperty paymentDate;
    private SimpleStringProperty paymentMethod;

    public Payment(String paymentId, String bookingId, String amount, String paymentDate, String paymentMethod) {
        this.paymentId = new SimpleStringProperty(paymentId);
        this.bookingId = new SimpleStringProperty(bookingId);
        this.amount = new SimpleStringProperty(amount);
        this.paymentDate = new SimpleStringProperty(paymentDate);
        this.paymentMethod = new SimpleStringProperty(paymentMethod);
    }

    public SimpleStringProperty paymentIdProperty() {
        return paymentId;
    }

    public SimpleStringProperty bookingIdProperty() {
        return bookingId;
    }

    public SimpleStringProperty amountProperty() {
        return amount;
    }

    public SimpleStringProperty paymentDateProperty() {
        return paymentDate;
    }

    public SimpleStringProperty paymentMethodProperty() {
        return paymentMethod;
    }

    public String getPaymentId() {
        return paymentId.get();
    }

    public String getBookingId() {
        return bookingId.get();
    }

    public String getAmount() {
        return amount.get();
    }

    public String getPaymentDate() {
        return paymentDate.get();
    }

    public String getPaymentMethod() {
        return paymentMethod.get();
    }
}