package com.example.demo1;

import javafx.scene.chart.Axis;

import java.util.List;

public class CategoryAxis extends Axis<X> {
    @Override
    protected Object autoRange(double v) {
        return null;
    }

    @Override
    protected void setRange(Object o, boolean b) {

    }

    @Override
    protected Object getRange() {
        return null;
    }

    @Override
    public double getZeroPosition() {
        return 0;
    }

    @Override
    public double getDisplayPosition(X x) {
        return 0;
    }

    @Override
    public X getValueForDisplay(double v) {
        return null;
    }

    @Override
    public boolean isValueOnAxis(X x) {
        return false;
    }

    @Override
    public double toNumericValue(X x) {
        return 0;
    }

    @Override
    public X toRealValue(double v) {
        return null;
    }

    @Override
    protected List<X> calculateTickValues(double v, Object o) {
        return List.of();
    }

    @Override
    protected String getTickMarkLabel(X x) {
        return "";
    }
}
